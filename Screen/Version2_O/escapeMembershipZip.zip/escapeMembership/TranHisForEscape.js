import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context'

import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const TranHisForEscape = (props) => {
    // console.log("data: ", props?.route?.params?.data);
    const [transactionHis, setTransactionHis] = useState(props?.route?.params?.data);

    const navigation = useNavigation();
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F8F4EE"
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingBottom: 40}}>

        {/* Header */}
        <View style={styles.header}>

          <TouchableOpacity onPress={() => {navigation.goBack()}} style={styles.backBtn}>
            <Ionicons
              name="chevron-back"
              size={20}
              color="#000"
            />
          </TouchableOpacity>

          <Text style={styles.headerTitle}>
            Transactions
          </Text>

          <View style={{width: 28}} />
        </View>

        {/* Top Row */}
        <View style={styles.topRow}>

          <Text style={styles.historyText}>History</Text>

          {/* <TouchableOpacity style={styles.filterBtn}>
            <Text style={styles.filterText}>
              Filter
            </Text>

            <MaterialIcons
              name="tune"
              size={22}
              color="#000"
            />
          </TouchableOpacity> */}

        </View>

        {/* Transaction Card */}
        {transactionHis?.map((item, index) => {
            const formatDateTime = isoDate => {
                const date = new Date(isoDate);

                const formattedDate = date.toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                });

                const formattedTime = date.toLocaleTimeString('en-US', {
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true,
                });

                return `${formattedDate} | ${formattedTime}`;
            };
            // Usage
            const date = formatDateTime(item?.createdAt);
            return (
                <View key={index} style={styles.card}>

                {/* Top */}
                <View style={styles.cardTopRow}>

                    <View style={{flex: 1}}>
                    <Text style={styles.purchaseTitle}>
                        MEMBERSHIP PURCHASE
                    </Text>

                    <Text style={styles.idText}>
                        ID: {item?.paymentProof?.txnId}
                    </Text>
                    </View>

                    <View style={{paddingHorizontal: 10,paddingVertical: 5,borderRadius: 5,
                      backgroundColor:item?.status == 'active' ? '#15803D0D' : '#DB00040D',borderWidth: 1,
                      borderColor:item?.status == 'active' ? '#15803D' : '#DB0004',}}
                    >
                      {item?.status == 'active' ? 
                        <Text style={styles.statusText}>
                            {item?.status}
                        </Text>
                        :
                        <Text style={{fontFamily:'WorkSans-Medium',color: '#DB0004',fontSize: 10,}}>
                            {item?.status}
                        </Text>
                      }
                    </View>

                </View>

                {/* Bottom */}
                <View style={styles.bottomRow}>

                    <View>
                    <Text style={styles.dateText}>
                        {date}
                    </Text>

                    <Text style={styles.amount}>
                        ₹{item?.paymentProof?.paidAmount}
                    </Text>
                    </View>

                    <TouchableOpacity
                      onPress={() => {
                        if(item?.status == 'active'){
                            navigation.navigate('PaymentSuccessEscape', {paymentData: item})
                        }else{
                            navigation.navigate('PaymentFailedEscape', {paymentData: item})
                        }
                      }} 
                     style={styles.detailsBtn}>
                        <Text style={styles.detailsText}>VIEW DETAILS</Text>
                    </TouchableOpacity>

                </View>

                </View>
        )})}

      </ScrollView>
    </SafeAreaView>
  );
};

export default TranHisForEscape;

const GOLD = '#AC935C ';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F4EE',
  },

  header: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
  },

  backBtn: {
    // height: 20,
    // width: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },

  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
  },

  topRow: {
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
  },

  historyText: {
    fontFamily:'WorkSans-Medium',
    fontSize: 14,
    color: '#AC935C',
    fontWeight: '500',
  },

  filterBtn: {
    height: 52,
    paddingHorizontal: 28,
    borderRadius: 28,
    backgroundColor: '#F7F7F7',
    borderWidth: 1,
    borderColor: '#DDD4C6',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },

  filterText: {
    fontSize: 18,
    color: '#000',
    fontWeight: '500',
  },

  card: {
    marginTop: 15,
    marginHorizontal: 20,
    backgroundColor: '#F7F7F7',
    borderRadius: 10,
    paddingHorizontal: 22,
    paddingVertical: 24,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,

    elevation: 3,
  },

  cardTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },

  purchaseTitle: {
    fontFamily:'WorkSans-Medium',
    fontSize: 14,
    // fontWeight: '700',
    color: '#000',
  },

  idText: {
    marginTop: 5,
    fontFamily:'WorkSans-Regular',
    fontSize: 12,
    color: '#00000080',
    // fontWeight: '400',
  },

  statusBox: {
    
  },

  statusText: {
    fontFamily:'WorkSans-Medium',
    color: '#188038',
    fontSize: 10,
    fontWeight: '600',
  },

  bottomRow: {
    marginTop: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  dateText: {
    fontFamily:'WorkSans-Regular',
    fontSize: 12,
    color: '#00000080',
    marginBottom: 5,
  },

  amount: {
    fontFamily:'WorkSans-SemiBold',
    fontSize: 16,
    color: '#000',
    // fontWeight: '700',
  },

  detailsBtn: {
    // height: 58,
    paddingHorizontal: 14,
    paddingVertical:7,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#AC935C33',
    backgroundColor: '#FAF8F4',
    justifyContent: 'center',
    alignItems: 'center',
  },

  detailsText: {
    fontFamily:'WorkSans-SemiBold',
    fontSize: 12,
    fontWeight: '700',
    color: '#775A19',
  },
});